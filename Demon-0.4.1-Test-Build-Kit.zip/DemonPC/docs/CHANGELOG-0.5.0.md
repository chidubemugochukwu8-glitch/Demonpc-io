# DEMON 0.5.0 change log

- Added saved dark/light mode preference.
- Added optional short touch feedback tone on interactive navigation and buttons.
- Reworked Settings into appearance, sound, runtime and library sections.
- Updated UI palette to adapt to light mode and refreshed game tile surfaces.
- Updated app/version labels and GitHub Actions artifact name.

Not included: automatic EXE execution. Winlator launch remains external until its exact package/API and a supported game handoff are confirmed.
