# DEMON 0.4.0 — build and phone test guide

## What this test build is

This is a **launcher/runtime-bridge prototype**, not a standalone Windows emulator. The test APK should let you check the landscape interface, navigation, file picker, saved game shortcuts, settings, and whether it can open a separately installed Winlator app. It does not yet launch a selected `.exe` directly.

## Option A — build an APK with GitHub Actions (works from a phone)

1. Download and extract the project ZIP.
2. In your browser, sign in to GitHub and create a new **empty** repository, for example `DemonPC`. Do not initialize it with a README or license because the project already has files.
3. Upload the **contents** of the extracted `DemonPC` folder to the repository root. Ensure `.github/workflows/build-apk.yml` and `scripts/validate_project.py` are included. GitHub's web uploader may not upload hidden files in some flows; if `.github` is missing, the workflow will not appear. Use GitHub's web upload flow that preserves the `.github` directory, or upload the project using an Android Git client that supports hidden files.
4. Open the repository's **Actions** tab. Select **Build DEMON debug APK**, tap **Run workflow**, and confirm.
5. Wait for the run to finish. A green check means the workflow steps passed; open the run and scroll to **Artifacts**.
6. Download `DEMON-0.4.0-debug-apk`, extract it, and locate `app-debug.apk`.
7. On the Tecno phone, open the APK. If Android prompts you, allow your browser/file manager to install unknown apps for this one install. Only install an APK you built from the source you trust.

The first build needs internet access and may take several minutes. The workflow runs a preflight script and a real Gradle `assembleDebug` build. An APK artifact is only available if those steps succeed.

## Option B — build locally in AndroidIDE / Android Studio

Open the project folder and configure JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.7. Run the `assembleDebug` task. The APK should be created at `app/build/outputs/apk/debug/app-debug.apk`.

## Phone acceptance checklist

- [ ] App installs and opens without immediately crashing.
- [ ] App opens in landscape orientation.
- [ ] HOME, LIBRARY, RUNTIMES, and SETTINGS tabs all switch pages.
- [ ] Add a harmless test file (not a game you don't own) through **ADD FILE**; its filename appears in LIBRARY.
- [ ] Close and reopen DEMON; the saved shortcut remains.
- [ ] Remove the shortcut; the actual file remains untouched.
- [ ] Clear saved shortcuts from SETTINGS; only the library entries are cleared.
- [ ] CPU profile selection persists after reopening. These are display labels only.
- [ ] RUNTIMES shows whether a supported Winlator package is detected; test opening it only if Winlator was installed from a trusted source.
- [ ] Rotate/navigation, back button, and touch targets behave acceptably on the phone.

## Report a failure

Record the exact step, what you tapped, what appeared, Android version, and (if available) the GitHub Actions build log. Do not report “game emulation works” unless a real owned game has actually been launched and tested inside the runtime.

## Current limitations

- No bundled Windows/Wine/Box86/Box64 engine.
- No verified direct file handoff from DEMON to Winlator.
- No native x86/x64 translation or game-specific graphics tuning in DEMON itself.
- No APK build or physical-device run is implied by the source ZIP alone.
