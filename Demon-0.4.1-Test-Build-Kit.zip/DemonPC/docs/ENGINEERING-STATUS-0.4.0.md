# DEMON 0.4.0 engineering status

## This milestone
- Added Android package visibility entries for common Winlator package IDs.
- Added an external-runtime adapter that detects a supported installed Winlator launcher and opens it.
- Added a fallback link to the official Winlator GitHub releases page; DEMON never silently downloads or installs an APK.
- Added library actions that explain the current game handoff limitation and guide the user to place files in a folder accessible from Winlator.
- Updated Android app version to 0.4.0.

## Deliberate limitations
- The bridge does not launch a selected EXE inside Winlator. No stable public launch API or verified package-specific intent contract has been confirmed for the target Winlator build.
- Selected SAF content URIs are stored as DEMON shortcuts, but are not automatically exposed to Winlator's sandbox. For now the user must put files somewhere Winlator can browse and launch them inside Winlator.
- No Wine/Box64 binaries are bundled, no APK build has been produced, and no device runtime test has been performed in this environment.

## Validation performed
- Source and manifest inspected after edits.
- ZIP archive integrity checked after packaging.
- Android compilation/runtime test not performed: Gradle executable and Android SDK are unavailable in the build environment.
