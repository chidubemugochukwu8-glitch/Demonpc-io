#!/usr/bin/env python3
"""Small preflight checks for the DEMON Android project; not a substitute for Gradle build/tests."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
errors = []
required = [
    ROOT / "settings.gradle",
    ROOT / "build.gradle",
    ROOT / "app/build.gradle",
    ROOT / "app/src/main/AndroidManifest.xml",
    ROOT / "app/src/main/java/com/demonpc/emulator/MainActivity.java",
    ROOT / "app/src/main/res/values/styles.xml",
]
for path in required:
    if not path.is_file():
        errors.append(f"Missing required file: {path.relative_to(ROOT)}")

manifest = ROOT / "app/src/main/AndroidManifest.xml"
if manifest.is_file():
    try:
        ET.parse(manifest)
    except ET.ParseError as exc:
        errors.append(f"Manifest XML parse failed: {exc}")

app_gradle = ROOT / "app/build.gradle"
if app_gradle.is_file():
    text = app_gradle.read_text(encoding="utf-8")
    for pattern, label in [
        (r"compileSdk\s+35\b", "compileSdk 35"),
        (r"minSdk\s+26\b", "minSdk 26"),
        (r"versionName\s+'0\.5\.0'", "versionName 0.5.0"),
    ]:
        if not re.search(pattern, text):
            errors.append(f"app/build.gradle missing expected setting: {label}")

source = ROOT / "app/src/main/java/com/demonpc/emulator/MainActivity.java"
if source.is_file():
    text = source.read_text(encoding="utf-8")
    if "package com.demonpc.emulator;" not in text:
        errors.append("MainActivity package declaration does not match namespace")
    # This only catches obvious editing damage; it is not a Java parser/compiler.
    for opening, closing, label in [("{", "}", "braces"), ("(", ")", "parentheses"), ("[", "]", "brackets")]:
        if text.count(opening) != text.count(closing):
            errors.append(f"MainActivity delimiter count mismatch: {label}")

if errors:
    print("DEMON preflight FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print("DEMON preflight checks passed (file presence, manifest XML, key settings, basic delimiter counts).")
print("These checks do NOT prove Java compilation, APK generation, installation, or game execution.")
