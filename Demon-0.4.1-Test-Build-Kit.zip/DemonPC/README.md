# DEMON 0.4.0 — Android landscape launcher + external runtime bridge

DEMON is an early Android launcher prototype for a future Windows-game compatibility project. It is **not yet a Windows emulator** and does not execute `.exe` files.

## Implemented in 0.4.0
- Landscape-oriented Android UI with space-black starfield, silver panels and orange accents.
- HOME, LIBRARY, RUNTIMES and SETTINGS navigation.
- Android document picker to register a user-selected game file.
- Saved game shortcuts persist across app restarts using SharedPreferences.
- Persistent Intel Core i5 / Intel Core i7 / AMD Ryzen 5 display-profile selection. These are labels only and do not change the phone hardware.
- Duplicate URI detection, saved shortcut removal and clear-library action (does not delete game files).
- External Winlator package detection for several common package IDs, using Android package-visibility declarations.
- Runtime page can open an installed Winlator app or open the official GitHub releases page in a browser.
- Library Run / Info action gives honest instructions and opens the external runtime; it does not claim to pass a saved content URI directly to Winlator.

## Device target
Tecno Camon 18i, MediaTek Helio G85, Android ARM64. Actual behavior and performance still need testing on the target phone.

## Build requirements
- Android Studio or AndroidIDE with Android SDK platform 35 and a compatible JDK.
- Gradle 8.7+ compatible with Android Gradle Plugin 8.6.1.
- Internet may be needed on first build to resolve the Android Gradle Plugin and Android SDK components.

Open this project folder in Android Studio/AndroidIDE and build the `app` debug variant. The current environment did not have Gradle or an Android SDK available, so no APK build is claimed.

## Still required before DEMON can launch a game directly
1. Verify runtime package IDs against the exact Winlator build on the target phone.
2. Implement a reliable game-file handoff into a runtime-accessible location or a supported runtime API; the current bridge only opens Winlator and provides instructions.
3. Select and legally package a compatible ARM64 Windows compatibility runtime.
4. Integrate x86/x64 translation where required by the target game and device.
5. Add graphics backend selection, controller mapping, audio, storage permissions and crash/log reporting.
6. Test against real games on the target phone and document compatibility/performance.

A real Windows runtime is a substantial native-engine integration; the launcher UI alone cannot provide it.

## Build automation and test checklist

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. After uploading the project contents to a GitHub repository, run **Actions → Build DEMON debug APK → Run workflow**. If the workflow succeeds, download the `DEMON-0.4.0-debug-apk` artifact and install `app-debug.apk` on the phone. See [`docs/TESTING-GUIDE.md`](docs/TESTING-GUIDE.md) for exact steps and the phone acceptance checklist. The workflow builds a debug APK; it does not add Windows emulation or prove game compatibility.
