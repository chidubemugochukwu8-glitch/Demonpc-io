# DEMON 0.5.0 — Console-style Android game hub

DEMON is an Android game-library and external-runtime launcher prototype. It is **not itself a Windows emulator**. Windows game execution still happens inside a separately installed compatibility runtime such as Winlator.

## 0.5.0 updates
- Persistent dark and light appearance modes.
- Optional short touch feedback tones for DEMON buttons and navigation.
- Refined console-inspired visual styling with space-black / silver / orange identity in dark mode and a bright matching light mode.
- Settings page now includes appearance, touch-sound, runtime and library controls.
- Updated version label to 0.5.0.
- Retains HOME, LIBRARY, RUNTIMES and SETTINGS pages, saved game shortcuts, and supported external Winlator package detection.

## Winlator integration status
DEMON can detect certain common Winlator package IDs and open the installed app. It currently **does not pass a saved game file URI directly into a Winlator container or launch a Windows EXE automatically**. To implement reliable direct launch, the exact Winlator build/package and a supported launch API or file handoff must be verified on the target phone.

## Target device
Tecno Camon 18i, MediaTek Helio G85, Mali-G52. The new theme and sound controls require testing on the phone. Performance and game compatibility are not guaranteed.

## Build with GitHub Actions
1. Upload the contents of this `DemonPC` folder to the root of your GitHub repository (including `.github/workflows/build-apk.yml`).
2. Open **Actions → Build DEMON debug APK → Run workflow**, or push a commit to `main` / `master`.
3. Download the `DEMON-0.5.0-debug-apk` artifact from the completed workflow and install `app-debug.apk`.

The workflow builds a debug APK; do not treat a successful build as proof that the new UI works until you install and test it on the phone.
