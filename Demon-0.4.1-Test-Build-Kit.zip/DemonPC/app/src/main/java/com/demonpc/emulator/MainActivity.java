package com.demonpc.emulator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Random;

/** DEMON launcher prototype. It manages game shortcuts; it does not yet emulate Windows. */
public class MainActivity extends Activity {
    private static final String PREFS = "demon_launcher";
    private static final String KEY_GAMES = "games_json";
    private static final String KEY_PROFILE = "cpu_profile";
    private static final String KEY_DARK_MODE = "dark_mode";
    private static final String KEY_TOUCH_SOUNDS = "touch_sounds";
    private int bg, panel, orange, silver, white, muted, surface, stroke, chipSurface, activeProfile;
    private boolean darkMode = true, touchSounds = true;
    private ToneGenerator toneGenerator;
    private final ArrayList<GameEntry> games = new ArrayList<>();
    private SharedPreferences prefs;
    private String profile = "Intel Core i5", currentPage = "HOME";
    private LinearLayout content, navBar;
    private TextView pageLabel, footer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        profile = prefs.getString(KEY_PROFILE, "Intel Core i5");
        darkMode = prefs.getBoolean(KEY_DARK_MODE, true);
        touchSounds = prefs.getBoolean(KEY_TOUCH_SOUNDS, true);
        try { toneGenerator = new ToneGenerator(AudioManager.STREAM_MUSIC, 38); } catch (Exception ignored) { toneGenerator = null; }
        applyThemeColors();
        loadGames(); buildShell(); showPage("HOME");
    }

    private void applyThemeColors() {
        if (darkMode) {
            bg = Color.rgb(7, 9, 14); panel = Color.rgb(21, 24, 32); surface = Color.rgb(29, 34, 44);
            orange = Color.rgb(255, 91, 48); silver = Color.rgb(190, 198, 210); white = Color.rgb(244, 246, 250);
            muted = Color.rgb(153, 164, 181); stroke = Color.rgb(49, 55, 67); chipSurface = Color.rgb(31, 35, 44); activeProfile = Color.rgb(57, 37, 31);
        } else {
            bg = Color.rgb(239, 242, 248); panel = Color.rgb(255, 255, 255); surface = Color.rgb(247, 249, 252);
            orange = Color.rgb(222, 67, 31); silver = Color.rgb(76, 86, 103); white = Color.rgb(27, 32, 42);
            muted = Color.rgb(103, 113, 130); stroke = Color.rgb(211, 217, 226); chipSurface = Color.rgb(239, 242, 247); activeProfile = Color.rgb(255, 232, 222);
        }
    }

    private void playTouchSound() {
        if (touchSounds && toneGenerator != null) {
            try { toneGenerator.startTone(ToneGenerator.TONE_PROP_BEEP2, 38); } catch (Exception ignored) { }
        }
    }

    private void click(View target, View.OnClickListener listener) {
        target.setOnClickListener(v -> { playTouchSound(); listener.onClick(v); });
    }

    @Override protected void onDestroy() {
        if (toneGenerator != null) { toneGenerator.release(); toneGenerator = null; }
        super.onDestroy();
    }

    private void buildShell() {
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            int flags = darkMode ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(bg);
        frame.addView(new StarField(this, darkMode, bg, orange), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(8), dp(20), dp(7));
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("◆ DEMON", 23, orange, true); logo.setLetterSpacing(.08f);
        header.addView(logo, new LinearLayout.LayoutParams(0, -2, 1));
        navBar = new LinearLayout(this); navBar.setGravity(Gravity.CENTER); navBar.setOrientation(LinearLayout.HORIZONTAL);
        String[] tabs = {"HOME", "LIBRARY", "RUNTIMES", "SETTINGS"};
        for (String tab : tabs) {
            TextView item = text(tab, 10, silver, true); item.setGravity(Gravity.CENTER); item.setPadding(dp(9), dp(9), dp(9), dp(9));
            click(item, v -> showPage(tab)); navBar.addView(item);
        }
        header.addView(navBar, new LinearLayout.LayoutParams(0, -2, 2));
        TextView badge = text("ANDROID • ARM64", 10, muted, true); badge.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        header.addView(badge, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(header, lp(-1, 38, 0, 0, 0, 6));
        View rule = new View(this); rule.setBackgroundColor(stroke); root.addView(rule, lp(-1, 1, 0, 0, 0, 8));
        pageLabel = text("HOME", 10, orange, true); pageLabel.setLetterSpacing(.13f); root.addView(pageLabel, lp(-1, -2, 0, 0, 0, 6));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(0, 0, 0, dp(4));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        footer = text("DEMON 0.5.0 • GAME HUB", 9, muted, true); footer.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        root.addView(footer, lp(-1, 18, 0, 5, 0, 0)); setContentView(frame);
    }

    private void showPage(String page) {
        currentPage = page; pageLabel.setText("/ " + page); content.removeAllViews();
        if ("HOME".equals(page)) showHome();
        else if ("LIBRARY".equals(page)) showLibrary();
        else if ("RUNTIMES".equals(page)) showRuntimes();
        else showSettings();
        footer.setText("DEMON 0.5.0 • " + games.size() + " SAVED GAME(S) • WINLATOR BRIDGE");
    }

    private void showHome() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); content.addView(row, new LinearLayout.LayoutParams(-1, -1));
        LinearLayout left = card(); row.addView(left, new LinearLayout.LayoutParams(0, -1, 1.35f));
        left.addView(text("YOUR HANDHELD PC HUB", 10, orange, true));
        left.addView(text("PLAY BIG.\nCARRY DEMON.", 29, white, true), lp(-1, -2, 0, 5, 0, 6));
        left.addView(text("A console-style Windows game library for Android.", 12, silver, false), lp(-1, -2, 0, 0, 0, 9));
        LinearLayout chips = new LinearLayout(this); chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.addView(chip("SPACE BLACK")); chips.addView(space(6)); chips.addView(chip("BRUSHED SILVER")); chips.addView(space(6)); chips.addView(chip("ORANGE CORE"));
        left.addView(chips, lp(-1, -2, 0, 0, 0, 10));
        Button add = button("＋  ADD WINDOWS GAME FILE"); click(add, v -> chooseGame()); left.addView(add, lp(235, 43, 0, 0, 0, 6));
        Button library = secondaryButton("OPEN GAME LIBRARY  →"); click(library, v -> showPage("LIBRARY")); left.addView(library, lp(200, 38, 0, 2, 0, 0));

        LinearLayout right = card(); right.setPadding(dp(15), dp(14), dp(15), dp(14));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, -1, 1); rp.setMargins(dp(10), 0, 0, 0); row.addView(right, rp);
        right.addView(text("CPU PROFILE LABEL", 10, silver, true));
        LinearLayout profiles = new LinearLayout(this); profiles.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Intel Core i5", "Intel Core i7", "AMD Ryzen 5"};
        for (String name : names) { Button b = profileButton(name); click(b, v -> { profile = name; prefs.edit().putString(KEY_PROFILE, profile).apply(); showPage("HOME"); Toast.makeText(this, name + " profile selected", Toast.LENGTH_SHORT).show(); }); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(53), 1); p.setMargins(0, 0, dp(5), 0); profiles.addView(b, p); }
        right.addView(profiles, lp(-1, 53, 0, 9, 0, 6));
        right.addView(text("Selected: " + profile, 10, muted, false), lp(-1, -2, 0, 0, 0, 9));
        right.addView(text(runtimeStatusLabel(), 11, orange, true));
        right.addView(text("DEMON can connect to a separately installed Winlator runtime. DEMON does not bundle or control the runtime engine, and the CPU profile buttons are labels only.", 11, silver, false), lp(-1, -2, 0, 6, 0, 8));
        Button runtimeAction = button(isWinlatorInstalled() ? "OPEN WINLATOR RUNTIME  →" : "GET WINLATOR RUNTIME  →");
        click(runtimeAction, v -> openRuntimeOrDownload()); right.addView(runtimeAction, lp(235, 42, 0, 0, 0, 8));
        right.addView(text("DEVICE TARGET", 10, orange, true));
        right.addView(text("Tecno Camon 18i\nMediaTek Helio G85 • Android ARM64", 11, silver, false), lp(-1, -2, 0, 5, 0, 0));
    }

    private void showLibrary() {
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL); content.addView(top, lp(-1, -2, 0, 0, 0, 10));
        top.addView(text("YOUR GAME COLLECTION", 17, white, true), new LinearLayout.LayoutParams(0, -2, 1));
        Button add = button("＋ ADD FILE"); click(add, v -> chooseGame()); top.addView(add, lp(130, 40, 0, 0, 0, 0));
        if (games.isEmpty()) {
            LinearLayout empty = card(); empty.setGravity(Gravity.CENTER); empty.addView(text("NO GAMES ADDED YET", 16, white, true));
            empty.addView(text("Tap ADD FILE to select a Windows .exe, .msi or game archive. This saves a shortcut only; it does not run the game yet.", 11, silver, false), lp(-1, -2, 0, 7, 0, 0));
            content.addView(empty, new LinearLayout.LayoutParams(-1, dp(150))); return;
        }
        for (int i = 0; i < games.size(); i++) {
            final int index = i; GameEntry game = games.get(i);
            LinearLayout tile = new LinearLayout(this); tile.setGravity(Gravity.CENTER_VERTICAL); tile.setOrientation(LinearLayout.HORIZONTAL); tile.setPadding(dp(13), dp(10), dp(10), dp(10)); decorate(tile, surface, 13, true);
            LinearLayout details = new LinearLayout(this); details.setOrientation(LinearLayout.VERTICAL); details.addView(text(game.name, 13, white, true)); details.addView(text("WINDOWS FILE • REGISTERED SHORTCUT", 9, muted, true), lp(-1, -2, 0, 4, 0, 0));
            tile.addView(details, new LinearLayout.LayoutParams(0, -2, 1));
            Button launch = secondaryButton("RUN / INFO"); click(launch, v -> launchGameViaRuntime(game)); tile.addView(launch, lp(95, 37, 4, 0, 4, 0));
            Button remove = secondaryButton("REMOVE"); click(remove, v -> { games.remove(index); saveGames(); showPage("LIBRARY"); }); tile.addView(remove, lp(88, 37, 4, 0, 0, 0));
            content.addView(tile, lp(-1, -2, 0, 0, 0, 8));
        }
    }

    private void showRuntimes() {
        LinearLayout box = card(); content.addView(box, new LinearLayout.LayoutParams(-1, -2));
        box.addView(text("WINDOWS COMPATIBILITY RUNTIME", 17, white, true));
        box.addView(text(runtimeStatusLabel(), 12, orange, true), lp(-1, -2, 0, 9, 0, 8));
        box.addView(text("Runtime bridge: DEMON checks for a supported Winlator package and can open it. Windows execution still happens inside that separate runtime; DEMON does not yet inject or directly launch an EXE into its process.", 12, silver, false));
        Button open = button(isWinlatorInstalled() ? "OPEN INSTALLED WINLATOR" : "OPEN OFFICIAL WINLATOR RELEASES");
        click(open, v -> openRuntimeOrDownload()); box.addView(open, lp(260, 44, 0, 12, 0, 4));
        Button help = secondaryButton("HOW TO RUN A GAME"); click(help, v -> showRuntimeInstructions(null)); box.addView(help, lp(220, 42, 0, 4, 0, 0));
        box.addView(text("ENGINEERING CHECKLIST", 12, orange, true), lp(-1, -2, 0, 17, 0, 7));
        String[] steps = {"✓ Landscape launcher and navigation", "✓ Persistent game shortcuts and profile", "✓ External runtime detection / open bridge", "○ Direct per-game process handoff", "○ Bundle / license review for native runtime", "○ Controller mapping, graphics settings and device tests"};
        for (String step : steps) box.addView(text(step, 11, silver, false), lp(-1, -2, 0, 4, 0, 4));
    }

    private boolean isWinlatorInstalled() { return findWinlatorLaunchIntent() != null; }

    private Intent findWinlatorLaunchIntent() {
        String[] packages = {"com.winlator", "com.winlator.frost", "com.winlator.winebox64", "com.winlator.winebox"};
        for (String pkg : packages) {
            Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
            if (launch != null) return launch;
        }
        return null;
    }

    private String runtimeStatusLabel() {
        return isWinlatorInstalled() ? "EXTERNAL WINLATOR DETECTED • BRIDGE READY" : "NO SUPPORTED WINLATOR PACKAGE DETECTED";
    }

    private void openRuntimeOrDownload() {
        Intent launch = findWinlatorLaunchIntent();
        if (launch != null) {
            try { startActivity(launch); }
            catch (Exception e) { Toast.makeText(this, "Could not open the installed runtime", Toast.LENGTH_LONG).show(); }
            return;
        }
        new AlertDialog.Builder(this).setTitle("Winlator runtime not detected")
            .setMessage("Install Winlator from its official release page, then return to DEMON. Runtime installation and first-time container setup happen in Winlator. DEMON does not download or install third-party APKs silently.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Open official releases", (d, w) -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/brunodev85/winlator/releases"))); }
                catch (Exception e) { Toast.makeText(this, "Open github.com/brunodev85/winlator/releases in your browser", Toast.LENGTH_LONG).show(); }
            }).show();
    }

    private void launchGameViaRuntime(GameEntry game) {
        if (!isWinlatorInstalled()) {
            new AlertDialog.Builder(this).setTitle("Runtime required")
                .setMessage("DEMON saved “" + game.name + "” as a shortcut, but cannot execute it by itself. Install Winlator and keep the game files in a folder Winlator can browse, such as Download. DEMON will open the runtime when available.")
                .setNegativeButton("Later", null).setPositiveButton("Get runtime", (d, w) -> openRuntimeOrDownload()).show();
            return;
        }
        showRuntimeInstructions(game);
    }

    private void showRuntimeInstructions(GameEntry game) {
        String title = game == null ? "Run a game with DEMON + Winlator" : "Run " + game.name;
        String msg = (game == null ? "" : "DEMON shortcut: " + game.name + "\n\n")
            + "1. Put the game's files in Download or another folder Winlator can access.\n"
            + "2. Open Winlator and finish its first-time container setup.\n"
            + "3. In Winlator, open its file manager and browse to the game or installer.\n"
            + "4. Launch it inside Winlator. Return to DEMON for your saved library.\n\n"
            + "Important: the current bridge opens Winlator only; it does not pass this saved content URI directly to the Windows process.";
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setNegativeButton("Close", null)
            .setPositiveButton("Open Winlator", (d, w) -> openRuntimeOrDownload()).show();
    }

    private void showSettings() {
        LinearLayout box = card(); content.addView(box, new LinearLayout.LayoutParams(-1, -2));
        box.addView(text("PERSONALIZE YOUR DEMON", 17, white, true));
        box.addView(text("Make the hub feel like your own handheld console.", 11, silver, false), lp(-1, -2, 0, 5, 0, 8));

        box.addView(text("APPEARANCE", 10, orange, true), lp(-1, -2, 0, 12, 0, 5));
        Button theme = button(darkMode ? "☾  DARK MODE  • ON" : "☀  LIGHT MODE  • ON");
        click(theme, v -> {
            darkMode = !darkMode; prefs.edit().putBoolean(KEY_DARK_MODE, darkMode).apply();
            applyThemeColors(); buildShell(); showPage("SETTINGS");
        });
        box.addView(theme, lp(235, 43, 0, 0, 0, 4));
        box.addView(text(darkMode ? "Space-black panels, neon orange accents and silver details." : "Bright console surfaces with warm orange highlights.", 11, silver, false), lp(-1, -2, 0, 2, 0, 6));

        box.addView(text("SOUND FEEDBACK", 10, orange, true), lp(-1, -2, 0, 12, 0, 5));
        Button sound = secondaryButton(touchSounds ? "♫  TOUCH SOUNDS  • ON" : "♫  TOUCH SOUNDS  • OFF");
        click(sound, v -> { touchSounds = !touchSounds; prefs.edit().putBoolean(KEY_TOUCH_SOUNDS, touchSounds).apply(); showPage("SETTINGS"); if (touchSounds) playTouchSound(); });
        box.addView(sound, lp(235, 42, 0, 0, 0, 4));
        box.addView(text("Short game-style click tone on buttons and navigation. You can switch it off anytime.", 11, silver, false), lp(-1, -2, 0, 2, 0, 6));

        box.addView(text("DEVICE & RUNTIME", 10, orange, true), lp(-1, -2, 0, 12, 0, 5));
        box.addView(text("Tecno Camon 18i · Helio G85 · Mali-G52\nWinlator is a separate app; DEMON can open it, but direct per-game EXE handoff still needs a verified integration path.", 11, silver, false));
        Button runtime = secondaryButton("OPEN WINLATOR  →"); click(runtime, v -> openRuntimeOrDownload()); box.addView(runtime, lp(220, 40, 0, 9, 0, 0));

        box.addView(text("LIBRARY MANAGEMENT", 10, orange, true), lp(-1, -2, 0, 16, 0, 5));
        box.addView(text("Saved shortcuts: " + games.size() + " · Game files are never deleted by clearing this list.", 11, silver, false));
        Button reset = secondaryButton("CLEAR SAVED GAME SHORTCUTS"); click(reset, v -> new AlertDialog.Builder(this).setTitle("Clear game library?").setMessage("This removes DEMON's saved shortcuts only. Your actual game files will not be deleted.").setNegativeButton("Cancel", null).setPositiveButton("Clear", (d, w) -> { games.clear(); saveGames(); showPage("SETTINGS"); }).show());
        box.addView(reset, lp(250, 42, 0, 9, 0, 0));
    }

    private void showLaunchInfo(GameEntry game) { launchGameViaRuntime(game); }

    private void chooseGame() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        try { startActivityForResult(i, 101); } catch (Exception e) { Toast.makeText(this, "No file picker available on this device", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != 101 || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
        String name = queryName(uri); if (name == null || name.trim().isEmpty()) name = uri.getLastPathSegment();
        if (name == null) name = "Selected Windows game";
        for (GameEntry g : games) if (g.uri.equals(uri.toString())) { Toast.makeText(this, "That file is already in your library", Toast.LENGTH_SHORT).show(); showPage("LIBRARY"); return; }
        games.add(new GameEntry(name, uri.toString())); saveGames(); Toast.makeText(this, "Saved to DEMON library", Toast.LENGTH_SHORT).show(); showPage("LIBRARY");
    }

    private String queryName(Uri uri) {
        android.database.Cursor c = null;
        try { c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null); if (c != null && c.moveToFirst()) return c.getString(0); }
        catch (Exception ignored) { } finally { if (c != null) c.close(); }
        return null;
    }
    private void loadGames() {
        games.clear(); String raw = prefs.getString(KEY_GAMES, "[]");
        try { JSONArray a = new JSONArray(raw); for (int i = 0; i < a.length(); i++) { JSONObject o = a.getJSONObject(i); games.add(new GameEntry(o.optString("name", "Windows game"), o.optString("uri", ""))); } }
        catch (Exception ignored) { games.clear(); }
    }
    private void saveGames() {
        JSONArray a = new JSONArray();
        try { for (GameEntry g : games) { JSONObject o = new JSONObject(); o.put("name", g.name); o.put("uri", g.uri); a.put(o); } } catch (Exception ignored) { }
        prefs.edit().putString(KEY_GAMES, a.toString()).apply();
    }

    private LinearLayout card() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(17), dp(15), dp(17), dp(15)); decorate(l, panel, 18, true); return l; }
    private Button profileButton(String s) { Button b = secondaryButton(s.replace("Intel ", "").replace("AMD ", "")); b.setTextSize(10); if (profile.equals(s)) { GradientDrawable d = new GradientDrawable(); d.setColor(activeProfile); d.setCornerRadius(dp(11)); d.setStroke(dp(1), orange); b.setBackground(d); } return b; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(11); b.setTextColor(Color.WHITE); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false); GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{orange, Color.rgb(255, 116, 62)}); d.setCornerRadius(dp(12)); b.setBackground(d); return b; }
    private Button secondaryButton(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(10); b.setTextColor(white); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false); GradientDrawable d = new GradientDrawable(); d.setColor(surface); d.setCornerRadius(dp(10)); d.setStroke(dp(1), stroke); b.setBackground(d); return b; }
    private TextView chip(String s) { TextView t = text("✦ " + s, 8, silver, true); t.setPadding(dp(7), dp(6), dp(7), dp(6)); GradientDrawable d = new GradientDrawable(); d.setColor(chipSurface); d.setCornerRadius(dp(20)); d.setStroke(dp(1), stroke); t.setBackground(d); return t; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL); t.setLineSpacing(dp(2), 1f); return t; }
    private void decorate(View v, int color, int radius, boolean stroke) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); if (stroke) d.setStroke(dp(1), Color.rgb(49, 55, 67)); v.setBackground(d); }
    private View space(int w) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1)); return v; }
    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p; }
    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    private static class GameEntry { final String name, uri; GameEntry(String n, String u) { name = n; uri = u; } }
    private static class StarField extends View {
        private final Paint paint = new Paint(3); private final Random random = new Random(42);
        private final boolean dark; private final int background, accent;
        StarField(Activity a, boolean isDark, int bgColor, int accentColor) { super(a); dark = isDark; background = bgColor; accent = accentColor; setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c); c.drawColor(background); random.setSeed(42);
            if (dark) for (int i = 0; i < 150; i++) { float x = random.nextFloat() * getWidth(), y = random.nextFloat() * getHeight(); float r = i % 13 == 0 ? 1.8f : .65f; int alpha = i % 5 == 0 ? 180 : 75; paint.setColor(Color.argb(alpha, 190, 202, 220)); c.drawCircle(x, y, r, paint); }
            paint.setShader(new android.graphics.RadialGradient(getWidth() * .78f, getHeight() * .2f, Math.max(getWidth(), getHeight()) * .65f, new int[]{Color.argb(dark ? 25 : 20, Color.red(accent), Color.green(accent), Color.blue(accent)), Color.TRANSPARENT}, null, android.graphics.Shader.TileMode.CLAMP)); c.drawRect(0, 0, getWidth(), getHeight(), paint); paint.setShader(null);
        }
    }
}
